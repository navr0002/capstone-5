/** @type {import('tailwindcss').Config} */
module.exports = __CONFIG__
