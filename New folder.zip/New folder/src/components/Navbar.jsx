import React from "react";
import { Link } from "react-router-dom";

const Navbar = () => {
  return (
    <nav className="bg-gray-900 text-white px-6 py-4 flex justify-between items-center shadow-md">
      <Link to="/" className="text-xl font-bold">Task Manager</Link>
      <div>
        <Link to="/" className="text-sm hover:underline">Home</Link>
      </div>
    </nav>
  );
};

export default Navbar;
