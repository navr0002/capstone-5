import React from "react";
import { useTasks } from "../contexts/TaskContext";

const Task = ({ task, listId }) => {
  const { deleteTask, toggleTaskCompleted } = useTasks();

  return (
    <li className={`p-3 border rounded flex justify-between items-center ${task.completed ? "bg-gray-200" : "bg-white"}`}>
      <div>
        <input
          type="checkbox"
          checked={task.completed}
          onChange={() => toggleTaskCompleted(listId, task.id, task.completed)}
          className="mr-2"
        />
        <span className={task.completed ? "line-through text-gray-500" : ""}>
          {task.task} (P{task.priority})
        </span>
      </div>
      <button onClick={() => deleteTask(listId, task.id)} className="text-red-500">
        Delete
      </button>
    </li>
  );
};

export default Task;
