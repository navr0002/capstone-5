import React, { useState } from "react";
import { Link } from "react-router-dom";
import { useTasks } from "../contexts/TaskContext";

const Home = () => {
  const { lists, addList, deleteList, loading } = useTasks();
  const [listName, setListName] = useState("");

  const handleAddList = async (e) => {
    e.preventDefault();
    if (listName.trim()) {
      await addList(listName);
      setListName("");
    }
  };

  return (
    <div className="max-w-3xl mx-auto p-4">
      <h2 className="text-2xl font-bold mb-4">Your Lists</h2>

      <form onSubmit={handleAddList} className="mb-4 flex gap-2">
        <input
          type="text"
          className="border p-2 flex-1"
          placeholder="New list name"
          value={listName}
          onChange={(e) => setListName(e.target.value)}
        />
        <button type="submit" className="bg-blue-600 text-white px-4 py-2 rounded">
          Add List
        </button>
      </form>

      {loading ? (
        <p>Loading...</p>
      ) : (
        <ul className="space-y-2">
          {lists.map((list) => (
            <li key={list.id} className="border p-3 rounded flex justify-between items-center">
              <Link to={`/list/${list.id}`} className="font-semibold">{list.name}</Link>
              <button onClick={() => deleteList(list.id)} className="text-red-500">Delete</button>
            </li>
          ))}
        </ul>
      )}
    </div>
  );
};

export default Home;
