import React, { useEffect, useState } from "react";
import { useParams } from "react-router-dom";
import {
  collection,
  query,
  onSnapshot,
  orderBy,
} from "firebase/firestore";
import { db } from "../firebase/firebaseConfig";
import { useTasks } from "../contexts/TaskContext";
import AddTaskForm from "../components/AddTaskForm";
import Task from "../components/Task";

const ListPage = () => {
  const { id } = useParams();
  const [tasks, setTasks] = useState([]);
  const [showCompleted, setShowCompleted] = useState(true);
  const [listName, setListName] = useState("");
  const { lists } = useTasks();

  useEffect(() => {
    const currentList = lists.find((list) => list.id === id);
    if (currentList) {
      setListName(currentList.name);
    }
  }, [lists, id]);

  useEffect(() => {
    const q = query(
      collection(db, `lists/${id}/tasks`),
      orderBy("priority", "asc")
    );

    const unsubscribe = onSnapshot(q, (querySnapshot) => {
      const tasksArray = [];
      querySnapshot.forEach((doc) => {
        tasksArray.push({ id: doc.id, ...doc.data() });
      });
      setTasks(tasksArray);
    });

    return () => unsubscribe();
  }, [id]);

  const visibleTasks = tasks.filter(
    (task) => showCompleted || !task.completed
  );

  return (
    <div className="max-w-3xl mx-auto p-4">
      <h2 className="text-2xl font-bold mb-2">{listName}</h2>

      <div className="flex items-center justify-between mb-4">
        <span className="text-gray-600">{tasks.length} total tasks</span>
        <button
          onClick={() => setShowCompleted((prev) => !prev)}
          className="text-sm text-blue-500 underline"
        >
          {showCompleted ? "Hide" : "Show"} Completed
        </button>
      </div>

      <AddTaskForm listId={id} />

      <ul className="space-y-2 mt-4">
        {visibleTasks.map((task) => (
          <Task key={task.id} task={task} listId={id} />
        ))}
      </ul>
    </div>
  );
};

export default ListPage;
